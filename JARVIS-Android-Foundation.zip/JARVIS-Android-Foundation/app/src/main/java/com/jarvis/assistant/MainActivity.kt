package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101F31)
private val Cyan = Color(0xFF67DFFF)
private val Muted = Color(0xFF9CB2C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
private fun JarvisApp() {
    var currentTab by remember { mutableStateOf("HOME") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("SİSTEM HAZIR") }
    var messages by remember { mutableStateOf(listOf("J.A.R.V.I.S. işə hazırdır. AI provayderini qoşmaq üçün Settings bölməsindən istifadə edin.")) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy, surface = Panel, primary = Cyan,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Column(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0xFF0A1A2D), Navy))
                ).padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("J.A.R.V.I.S.", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF123044), shape = RoundedCornerShape(20.dp)) {
                        Text(status, color = Cyan, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                    }
                }
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Box(
                        Modifier.size(148.dp).background(
                            Brush.radialGradient(listOf(Color(0xFF1C789A), Color(0xFF102B43), Navy)),
                            CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(88.dp).background(Color(0xFF6ADFFF).copy(alpha = .12f), CircleShape))
                        Text("J", color = Cyan, fontSize = 54.sp, fontWeight = FontWeight.Light)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("HOME", "CHAT", "SETTINGS").forEach { tab ->
                        FilterChip(
                            selected = currentTab == tab,
                            onClick = { currentTab = tab },
                            label = { Text(tab) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF16465B),
                                selectedLabelColor = Cyan
                            )
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                when (currentTab) {
                    "HOME" -> {
                        Text("Sistem paneli", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(10.dp))
                        InfoTile("AI bağlantısı", "Hələ konfiqurasiya edilməyib")
                        InfoTile("Səs sistemi", "Növbəti mərhələdə əlavə olunacaq")
                        InfoTile("Təhlükəsizlik", "API açarları hələ saxlanılmır")
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { currentTab = "CHAT" },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16465B))
                        ) { Text("JARVIS ilə söhbət", color = Cyan) }
                    }
                    "CHAT" -> {
                        Text("Söhbət", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("Bu ilkin versiyada mesajlar cihazda lokal göstərilir; AI bağlantısı hələ aktiv deyil.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(messages) { msg ->
                                Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                                    Text(msg, Modifier.padding(12.dp), color = Color.White)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = input, onValueChange = { input = it },
                                modifier = Modifier.weight(1f),
                                placeholder = { Text("Mesaj yaz...") },
                                singleLine = true
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                if (input.isNotBlank()) {
                                    messages = messages + "Sən: $input"
                                    messages = messages + "JARVIS: AI provayderi qoşulmadığı üçün bu versiyada cavab yarada bilmirəm."
                                    input = ""
                                }
                            }) { Text("Göndər") }
                        }
                    }
                    else -> {
                        Text("Parametrlər", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        InfoTile("OpenRouter", "API inteqrasiyası növbəti mərhələdə")
                        InfoTile("Google Gemini", "API inteqrasiyası növbəti mərhələdə")
                        InfoTile("ElevenLabs", "Səs sintezi növbəti mərhələdə")
                        Text("Bu versiyada API açarı daxil etmə sahəsi yoxdur. Təhlükəsiz credential vault hazırlanandan sonra əlavə ediləcək.", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("FOUNDATION BUILD • v0.1.0 • HONOR PAD X9a TARGET", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun InfoTile(title: String, detail: String) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        color = Panel, shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}
