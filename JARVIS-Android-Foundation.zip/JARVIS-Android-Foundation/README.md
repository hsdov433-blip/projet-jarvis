# J.A.R.V.I.S. Android — Foundation

This is the first native Android foundation milestone for the J.A.R.V.I.S. project.

## Current status
- Native Kotlin + Jetpack Compose Android application.
- Minimum Android API 28.
- Compile SDK 36.
- Debug APK build through GitHub Actions.
- Dashboard, local chat shell, and provider-settings overview.

## Important limitations
This foundation build does **not** yet connect OpenRouter, Gemini, Gemini Live, or ElevenLabs. It does not yet implement speech recognition, speech synthesis, device actions, persistent memory, or credential storage. The chat explicitly reports that no AI provider is connected; it does not fabricate AI responses.

## Build
GitHub Actions runs `gradle :app:assembleDebug` using JDK 17 and Gradle 8.13. The APK artifact is `app-debug.apk`.

## Next milestones
1. Verify the cloud build and install the APK on the target device.
2. Add encrypted credential storage and provider configuration.
3. Implement real OpenRouter and Gemini requests with cancellation and error handling.
4. Add native speech and allowlisted Android actions.
